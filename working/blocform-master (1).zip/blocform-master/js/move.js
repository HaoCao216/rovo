$(".close-all-iframe").click(function(){      
  $('iframe').attr('src', $('iframe').attr('src'));
});



document.getElementById('join-token-button').onmouseover = function(){
  document.getElementById('whitepapper-button').style.backgroundColor = '#c10000';
  document.getElementById('whitepapper-button').style.color = '#ffffff';
}
document.getElementById('join-token-button').onmouseout = function(){
  document.getElementById('whitepapper-button').style.backgroundColor = '#ffffff';
  document.getElementById('whitepapper-button').style.color = '#c10000';
}


var countDownDate = new Date("May 15, 2018 20:04:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();
  
  // Find the distance between now an the count down date
  var distance = countDownDate - now;
  
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  
  // Output the result in an element with id="demo"
  if(days<10){
    document.getElementById("count-down-days").innerHTML ="0" + days;
  }
  else{
    document.getElementById("count-down-days").innerHTML = days;
  }
  if(hours < 10){
    document.getElementById("count-down-hours").innerHTML = "0" + hours;
  }
  else{
    document.getElementById("count-down-hours").innerHTML = hours;
  }
   if(minutes < 10){
    document.getElementById("count-down-minutes").innerHTML =  "0" + minutes;
  }
  else{
    document.getElementById("count-down-minutes").innerHTML =  minutes;
  }
   if(seconds < 10){
    document.getElementById("count-down-seconds").innerHTML ="0" + seconds;
  }
  else{
    document.getElementById("count-down-seconds").innerHTML = seconds;
  }


  // If the count down is over, write some text 
  if (days <= 0 && hours <= 0 && minutes <= 0 && seconds <= 0) {
    document.getElementById("count-down-days").innerHTML = "0";
    document.getElementById("count-down-hours").innerHTML ="0";
    document.getElementById("count-down-minutes").innerHTML =  "0";
    document.getElementById("count-down-seconds").innerHTML = "0";
    clearInterval(x);
  }
}, 1000);





// $(window).on("scroll", function() {
//   if ($(this).scrollTop() > 50) {
//      $("#header").addClass("not-transparent");
//   }
//   else {
//       $("#header").removeClass("not-transparent");
//   }
//  });

$(".about-us").click(function() {
  $('.navbar-collapse').removeClass('show');
  $('html,body').animate({scrollTop: $(".review-app-v2").offset().top - 50},
  'slow');
});

$(".partners").click(function() {
  $('.navbar-collapse').removeClass('show');
  $('html,body').animate({
  scrollTop: $(".partners-site").offset().top - 50 },
  'slow');
});
$(".events").click(function() {
  $('.navbar-collapse').removeClass('show');
  $('html,body').animate({
  scrollTop: $(".events-site").offset().top },
  'slow');
});
$(".team").click(function() {
  $('.navbar-collapse').removeClass('show');
  $('html,body').animate({
  scrollTop: $(".our-team").offset().top - 100 },
  'slow');
});
$(".eco").click(function() {
  $('.navbar-collapse').removeClass('show');
  $('html,body').animate({
  scrollTop: $(".eco-system").offset().top },
  'slow');
});
$(".road-map-li").click(function() {
  $('.navbar-collapse').removeClass('show');
  $('html,body').animate({
  scrollTop: $(".road-map").offset().top - 20},
  'slow');
});
$(".contact-us-nav").click(function() {
  $('.navbar-collapse').removeClass('show');
  $('html,body').animate({
  scrollTop: $("footer").offset().top},
  'slow');
});

$(".conference-button").click(function() {
  $('.applications-button').removeClass('active-button')
  $('.conference-button').addClass('active-button')
  $('.logo-events').css('display','none')
  $('.swiper-slide-events').css('display','block')
});
$(".applications-button").click(function() {
  $('.applications-button').addClass('active-button')
  $('.conference-button').removeClass('active-button')
  $('.logo-events').css('display','block')
  $('.swiper-slide-events').css('display','none')
});
// Add animation
var $window = $(window);
$window.on('scroll', function() {
  var scrollTop = $window.scrollTop();
  var $ver0 = $('.events-site');
  var $ver1 = $('.about-post-sm');
  var $ver2 = $('.animation-info');
  var $ver3 = $('.our-advisor-animation');
  var $ver5 = $('.img-logo-eco');
  var $ver6 = $('.eco-system-text');
  var $ver7 = $('.partners-site');
  var $ver8 = $('.animation-slider');
  var $ver9 = $('.diagram-content');
  var $ver91 = $('.description');
  var $ver92 = $('.node');
  var $ver10 = $('.animation-count-down');
  var $ver11 = $('.about-tech'); 
  var $ver12 = $('.update-advantages');
  var scrollBottom = $(window).scrollTop() + $(window).height();

  if ( (scrollBottom >= $('.c-v2').offset().top) && ( scrollTop <= ($('.c-v2').offset().top + $(".c-v2").height()) ) )  {
    setTimeout(function(){
      $('.time-countdown-day').addClass('animated fadeInDown')
  },300)
    setTimeout(function(){
      $('.time-countdown-hours').addClass('animated fadeInDown')
  },500)
    setTimeout(function(){
      $('.time-countdown-minutes').addClass('animated fadeInDown')
  },700)
     setTimeout(function(){
      $('.time-countdown-seconds').addClass('animated fadeInDown')
  },900)
  }
  else{
      $('.time-countdown-number').removeClass('animated fadeInDown');
  }

  if ( (scrollBottom >= $('.c-v2').offset().top) && ( scrollTop <= ($('.c-v2').offset().top + $(".c-v2").height()) ) ) {
    $('.c-v2-content-animated').addClass('animated zoomIn');
  }
  else{
   $('.c-v2-content-animated').removeClass('animated zoomIn');
  }

  if ( (scrollBottom >= $('.c-v1').offset().top) && ( scrollTop <= ($('.c-v1').offset().top + $(".c-v1").height()) ) ) {
    $('.c-v1').addClass('animated zoomIn');
  }
  else{
   $('.c-v1').removeClass('animated zoomIn');
  }

  

  if ( (scrollBottom >= $('.online-payment-content').offset().top) && ( scrollTop <= ($('.online-payment-content').offset().top + $(".online-payment-content").height()) ) ) {
    $('.online-payment-content').addClass('animated fadeInLeft');
  }
  else{
   $('.online-payment-content').removeClass('animated fadeInLeft');
  }

  if ( (scrollBottom >= $('.online-payment-img-animated').offset().top) && ( scrollTop <= ($('.online-payment-img-animated').offset().top + $(".online-payment-img-animated").height()) ) ) {
    $('.online-payment-img-animated').addClass('animated fadeInRight');
  }
  else{
    $('.online-payment-img-animated').removeClass('animated fadeInRight');
  }

  if ( (scrollBottom >= $('.title-eco-animated').offset().top) && ( scrollTop <= ($('.title-eco-animated').offset().top + $(".title-eco-animated").height()) ) ) {
    $('.title-eco-animated').addClass('animated zoomIn');
  }
  else{
    $('.title-eco-animated').removeClass('animated zoomIn');
  }

  if ( (scrollBottom >= $('.eco-part-2-animated').offset().top) && ( scrollTop <= ($('.eco-part-2-animated').offset().top + $(".eco-part-2-animated").height()) ) ) {
    $('.eco-v2-text').addClass('animated fadeInDown');
    $('.eco-v2-img').addClass('animated fadeInUp');
  }
  else{
    $('.eco-v2-text').removeClass('animated fadeInDown');
    $('.eco-v2-img').removeClass('animated fadeInUp');
  }

  if ( (scrollBottom >= $('.benefit-fs-content').offset().top) && ( scrollTop <= ($('.benefit-fs-content').offset().top + $(".benefit-fs-content").height()) ) ) {
    $('.benefit-fs-content').addClass('animated fadeInRight');
  }
  else{
    $('.benefit-fs-content').removeClass('animated fadeInRight');
  }
  if ( (scrollBottom >= $('.benefit-nd-content').offset().top) && ( scrollTop <= ($('.benefit-nd-content').offset().top + $(".benefit-nd-content").height()) ) ) {
    $('.benefit-nd-content').addClass('animated fadeInLeft');
  }
  else{
    $('.benefit-nd-content').removeClass('animated fadeInLeft');
  }
  if ( (scrollBottom >= $('.benefit-th-content').offset().top) && ( scrollTop <= ($('.benefit-th-content').offset().top + $(".benefit-th-content").height()) ) ) {
    $('.benefit-th-content').addClass('animated fadeInRight');
  }
  else{
    $('.benefit-th-content').removeClass('animated fadeInRight');
  }
  if ( (scrollBottom >= $('.join-ico').offset().top) && ( scrollTop <= ($('.join-ico').offset().top + $(".join-ico").height()) ) ) {
    $('.button-join').addClass('animated zoomIn');
  }
  else{
    $('.button-join').removeClass('animated zoomIn');
  }

  if ( (scrollBottom >= $('.about-partners-animated').offset().top) && ( scrollTop <= ($('.about-partners-animated').offset().top + $(".about-partners-animated").height()) ) ) {
    $('.about-partners-animated').addClass('animated zoomIn');
  }
  else{
    $('.about-partners-animated').removeClass('animated zoomIn');
  }

  if ( (scrollBottom >= $('.logo-partners-full').offset().top) && ( scrollTop <= ($('.logo-partners-full').offset().top + $(".logo-partners-full").height()) ) ) {
    abc();
    function abc() {
      var i = 1;
      $('.logo-animated').eq(0).addClass('animated fadeInDown');
      var b = setInterval(function() {
        $('.logo-animated').eq(i).addClass('animated fadeInDown');
          i++;
          if (i > 8) {
            myStopFunction(b);
        }
      }, 200)
    }
    function myStopFunction(b) {
      clearTimeout(b);
    }
  }
  else{
    $('.logo-animated').removeClass('animated fadeInDown');
  }

  if ( (scrollBottom >= $('.our-advisor-animation').offset().top) && ( scrollTop <= ($('.our-advisor-animation').offset().top + $(".our-advisor-animation").height()) ) ) {
    $ver3.addClass('animated fadeInUp');
  }
  else{
    $ver3.removeClass('animated fadeInUp');
  }

  if ( (scrollBottom >= $('.animation-slider').offset().top) && ( scrollTop <= ($('.animation-slider').offset().top + $(".animation-slider").height()) ) )  {
    $ver8.addClass('animated zoomIn');

  }
  else{
    $ver8.removeClass('animated zoomIn');
  }

  if ( (scrollBottom >= $('.diagram-content').offset().top) && ( scrollTop <= ($('.diagram-content').offset().top + $(".diagram-content").height()) ) )  {
    setTimeout(function(){
      $('.node').addClass('animated zoomIn')
    },100)
      setTimeout(function(){
        $('.description[index="1"]').addClass('show-animation')
    },100)
    setTimeout(function(){
        $('.description[index="2"]').addClass('show-animation')
    },300)
    setTimeout(function(){
        $('.description[index="3"]').addClass('show-animation')
    },600)
    setTimeout(function(){
        $('.description[index="4"]').addClass('show-animation')
    },900)
    setTimeout(function(){
        $('.description[index="5"]').addClass('show-animation')
    },1200)
          setTimeout(function(){
        $('.description[index="6"]').addClass('show-animation')
    },1500)
    setTimeout(function(){
        $('.description[index="7"]').addClass('show-animation')
    },1800)
    setTimeout(function(){
        $('.description[index="8"]').addClass('show-animation')
    },1900)
    setTimeout(function(){
        $('.description[index="9"]').addClass('show-animation')
    },2200)
  }
  else{
    $ver91.removeClass('show-animation');
    $ver92.removeClass('animated zoomIn');
  }

  if ( (scrollBottom >= $('.events-site').offset().top) && ( scrollTop <= ($('.events-site').offset().top + $(".events-site").height()) ) )  {
     setTimeout(function(){
      $('.oval_1').addClass('animated fadeInLeft')
  },100)
  setTimeout(function(){
      $('.oval_2').addClass('animated fadeInRight')
  },300)
  }
  else{
      $('.oval').removeClass('animated fadeInLeft fadeInRight');
  }
});



function changeImage(index) {
  var a = document.getElementById('england-flag').src;
  var b = document.getElementById('spain-flag').src;
  var c = document.getElementById('china-flag').src;
  if(index === 1){
  document.getElementById('flag-active').src= a;
  }
  if(index === 2){
  document.getElementById('flag-active').src= b;
  }
  if(index === 3){
  document.getElementById('flag-active').src= c;
  }
}