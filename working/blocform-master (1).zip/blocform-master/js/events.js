function myFunction() {
   	var x = 1; 
   	var y = 1;
   	var z = 1;
    let htmlString1 =

    `
		
    `
    let htmlString2 =

    `
		
    `
    let htmlString3 =

    `
		
    `
    for ( x = 1; x < 24; x ++){
    	htmlString1 += 
    	`
    		 <img  src="img/events/7_10_2017/${x}.jpg">

    	`
    }

    for ( y = 1; y < 11; y ++){
    	htmlString2 += 
    	`
    		 <img  src="img/events/14_12_2017/${y}.jpg">

    	`
    }
    for ( z = 1; z< 22; z ++){
    	htmlString3 += 
    	`
    		 <img  src="img/events/15_11_2017/${z}.jpg">

    	`
    }
   
     document.getElementById("img-event-1").innerHTML = htmlString1;
     document.getElementById("img-event-2").innerHTML = htmlString2;
     document.getElementById("img-event-3").innerHTML = htmlString3;
}
myFunction();
